<!-- Success msg for creating slider -->
<?php if(session('successC')): ?>
    <div class="alert alert-success ">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <i class="material-icons">close</i>
        </button>
        <span> <?php echo e(session('successC')); ?> </span>
    </div>
<?php endif; ?>

<!-- Success msg for edit slider -->
<?php if(session('successU')): ?>
    <div class="alert alert-success ">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <i class="material-icons">close</i>
        </button>
        <span> <?php echo e(session('successU')); ?> </span>
    </div>
<?php endif; ?>

<!-- Success msg for delete slider -->
<?php if(session('successD')): ?>
    <div class="alert alert-success ">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <i class="material-icons">close</i>
        </button>
        <span> <?php echo e(session('successD')); ?> </span>
    </div>
<?php endif; ?>

<!-- error validation  -->
<?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger ">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="material-icons">close</i>
            </button>
            <span> <?php echo e($error); ?> </span>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
